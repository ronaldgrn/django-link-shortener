from django.contrib import admin
from .models import UrlMap, UrlProfile

# Register your models here.
admin.site.register(UrlMap)
admin.site.register(UrlProfile)
